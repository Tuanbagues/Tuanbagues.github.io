# Codemirror 6 Themes

Not perfect themes for [cm6](https://github.com/codemirror/dev/), generated from [vscode themes](https://github.com/microsoft/vscode/tree/main/extensions/theme-quietlight).

- [theme-abyss](https://github.com/microsoft/vscode/tree/main/extensions/theme-abyss)
- [~~theme-defaults~~](https://github.com/microsoft/vscode/tree/main/extensions/theme-defaults)
- [theme-kimbie-dark](https://github.com/microsoft/vscode/tree/main/extensions/theme-kimbie-dark)
- [theme-monokai-dimmed](https://github.com/microsoft/vscode/tree/main/extensions/theme-monokai-dimmed)
- [theme-monokai](https://github.com/microsoft/vscode/tree/main/extensions/theme-monokai)
- [theme-quietlight](https://github.com/microsoft/vscode/tree/main/extensions/theme-quietlight)
- [theme-red](https://github.com/microsoft/vscode/tree/main/extensions/theme-red)
- [theme-seti](https://github.com/microsoft/vscode/tree/main/extensions/theme-seti)
- [theme-solarized-dark](https://github.com/microsoft/vscode/tree/main/extensions/theme-solarized-dark)
- [theme-solarized-light](https://github.com/microsoft/vscode/tree/main/extensions/theme-solarized-light)
- [theme-tomorrow-night-blue](https://github.com/microsoft/vscode/tree/main/extensions/theme-tomorrow-night-blue)
- [Andromeda](https://github.com/EliverLara/Andromeda/blob/master/themes/Andromeda-color-theme.json)
- [Copilot](https://github.com/benjaminbenais/copilot-theme/blob/main/themes/Copilot%20Theme-color-theme.json)
- [White](https://github.com/xthezealot/white-theme-vscode/tree/master/themes)
