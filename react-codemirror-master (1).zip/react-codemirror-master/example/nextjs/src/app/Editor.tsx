'use client';

import CodeMirror from '@uiw/react-codemirror';

export default function Editor() {
  return <CodeMirror value="aaaa" theme="dark" width="500px" height="500px" onChange={() => {}} />;
}
