// import Editor from './_editor';
import { MergeExample } from './_editor/Com';

export default function Merge() {
  return (
    <div>
      <MergeExample />
    </div>
  );
}
