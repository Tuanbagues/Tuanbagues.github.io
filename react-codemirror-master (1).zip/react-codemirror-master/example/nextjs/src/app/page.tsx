import Editor from './Editor';

export default function Home() {
  return (
    <main className="flex min-h-screen items-center justify-between p-24">
      <Editor />
    </main>
  );
}
